# EDA-on-Sails-Data
Performed analysis to identify numerous market Sailors and their making in different cities to improve the Business by knowing fixable potholes. Skills:- Visualization, Exploratory Data Analysis. Tools:- Python, Pandas, Matplotlib and Seaborn 
